from fastapi import APIRouter
from pydantic import BaseModel
from app.core.score_schema import Score

router = APIRouter()

class GenerateRequest(BaseModel):
    score: Score
    selection: dict | None = None
    intent: str = "motif"
    style: str | None = None
    n: int = 5

class Candidate(BaseModel):
    id: str
    delta_events: list[dict]
    summary: str

class GenerateResponse(BaseModel):
    candidates: list[Candidate]

@router.post("", response_model=GenerateResponse)
def generate(req: GenerateRequest):
    # Stub: route to Stochastic + Markov + CR-Counter in Phase 2/3.
    n = max(1, min(req.n, 10))
    return GenerateResponse(candidates=[
        Candidate(id=f"cand_{i+1}", delta_events=[], summary="(stub)")
        for i in range(n)
    ])
