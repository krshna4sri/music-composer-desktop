from fastapi import APIRouter
from pydantic import BaseModel
from app.core.score_schema import Score

router = APIRouter()

class Violation(BaseModel):
    type: str
    severity: str
    message: str
    locations: list[dict] = []

class ValidateResponse(BaseModel):
    violations: list[Violation] = []

@router.post("/validate", response_model=ValidateResponse)
def validate(score: Score):
    # Stub: wire CR-Counter checks here
    return ValidateResponse(violations=[])

class RepairResponse(BaseModel):
    repaired_score: Score
    repair_log: list[str] = []

@router.post("/repair", response_model=RepairResponse)
def repair(score: Score):
    # Stub: wire CR-Counter repair here
    return RepairResponse(repaired_score=score, repair_log=["(stub) no changes"])
