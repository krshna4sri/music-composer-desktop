from fastapi import APIRouter
from app.core.score_schema import Score, ProjectTemplate
from app.core.templates import make_grand_staff, make_string_quartet

router = APIRouter()

@router.get("")
def list_templates():
    return [
        {"id": "grand_staff", "name": "Grand Staff (Piano)"},
        {"id": "string_quartet", "name": "String Quartet"},
    ]

@router.post("/new", response_model=Score)
def new_project(req: ProjectTemplate):
    if req.template_id == "grand_staff":
        return make_grand_staff(title=req.title or "Grand Staff")
    if req.template_id == "string_quartet":
        return make_string_quartet(title=req.title or "String Quartet")
    raise ValueError(f"Unknown template_id: {req.template_id}")
