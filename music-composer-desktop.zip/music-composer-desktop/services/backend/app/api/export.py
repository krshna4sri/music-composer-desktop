from fastapi import APIRouter
from pydantic import BaseModel
from app.core.score_schema import Score
from app.core.converters_musicxml import score_to_musicxml

router = APIRouter()

class MusicXMLResponse(BaseModel):
    musicxml: str

@router.post("/musicxml", response_model=MusicXMLResponse)
def export_musicxml(score: Score):
    return MusicXMLResponse(musicxml=score_to_musicxml(score))
