from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class RagQuery(BaseModel):
    question: str
    style_hint: str | None = None
    selection: dict | None = None
    context: dict | None = None

class RagAnswer(BaseModel):
    answer: str
    citations: list[dict] = []
    suggested_actions: list[dict] = []

@router.post("/query", response_model=RagAnswer)
def rag_query(q: RagQuery):
    # Stub: wire to your MusicLibRAG here (Ollama + FAISS).
    style = q.style_hint or "baroque/classical"
    answer = (
        f"Here are a few *{style}* continuation ideas:\n"
        "- Try a short sequence (repeat motif starting on different scale degrees).\n"
        "- Use imitation at the 5th or octave for 1–2 bars.\n"
        "- Aim for a cadence in the last bar (V→I or ii6→V→I).\n"
        "Click 'Generate options' to create 5 candidate phrases."
    )
    return RagAnswer(
        answer=answer,
        citations=[],
        suggested_actions=[
            {"type": "generate", "intent": "continue", "n": 5, "style": style},
            {"type": "explain", "topic": "cadence"},
        ],
    )
