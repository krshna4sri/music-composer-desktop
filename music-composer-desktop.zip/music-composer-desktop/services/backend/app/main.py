from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.health import router as health_router
from app.api.templates import router as templates_router
from app.api.export import router as export_router
from app.api.rag import router as rag_router
from app.api.generate import router as generate_router
from app.api.constraints import router as constraints_router

app = FastAPI(title="Music Composer Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(templates_router, prefix="/templates", tags=["templates"])
app.include_router(export_router, prefix="/export", tags=["export"])
app.include_router(rag_router, prefix="/rag", tags=["rag"])
app.include_router(generate_router, prefix="/generate", tags=["generate"])
app.include_router(constraints_router, prefix="/constraints", tags=["constraints"])
