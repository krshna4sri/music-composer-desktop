from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal, Optional

Clef = Literal["treble", "bass", "alto", "tenor"]
InstrumentId = Literal["piano", "violin", "viola", "cello"]

class NoteEvent(BaseModel):
    id: str
    part_id: str
    voice: int = 1
    staff: int = 1
    midi: int = Field(..., ge=0, le=127)
    start_q: float = Field(..., ge=0)
    dur_q: float = Field(..., gt=0)
    velocity: int = Field(90, ge=1, le=127)

class Part(BaseModel):
    id: str
    name: str
    instrument: InstrumentId
    clef: Clef
    staff_count: int = 1

class TimeSignature(BaseModel):
    beats: int = 4
    beat_type: int = 4

class KeySignature(BaseModel):
    fifths: int = 0

class ScoreMeta(BaseModel):
    title: str = "Untitled"
    composer: str = ""
    tempo_bpm: int = 100
    time: TimeSignature = TimeSignature()
    key: KeySignature = KeySignature()
    measures: int = 8

class Score(BaseModel):
    meta: ScoreMeta = ScoreMeta()
    parts: list[Part] = []
    notes: list[NoteEvent] = []

class ProjectTemplate(BaseModel):
    template_id: str
    title: Optional[str] = None
