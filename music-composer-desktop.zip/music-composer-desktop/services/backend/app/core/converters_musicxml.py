from __future__ import annotations
from xml.sax.saxutils import escape
from app.core.score_schema import Score, NoteEvent

_STEP_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]

def midi_to_pitch(midi: int):
    step = _STEP_NAMES[midi % 12]
    octave = midi // 12 - 1
    if "#" in step:
        return step[0], 1, octave
    return step, 0, octave

def clef_to_musicxml(clef: str, number: int = 1) -> str:
    if clef == "treble":
        sign, line = "G", 2
    elif clef == "bass":
        sign, line = "F", 4
    elif clef == "alto":
        sign, line = "C", 3
    elif clef == "tenor":
        sign, line = "C", 4
    else:
        sign, line = "G", 2
    return f"<clef number=\"{number}\"><sign>{sign}</sign><line>{line}</line></clef>"

def note_type_from_dur(dur_q: float) -> str:
    if abs(dur_q - 4) < 1e-6: return "whole"
    if abs(dur_q - 2) < 1e-6: return "half"
    if abs(dur_q - 1) < 1e-6: return "quarter"
    if abs(dur_q - 0.5) < 1e-6: return "eighth"
    return "quarter"

def score_to_musicxml(score: Score) -> str:
    title = escape(score.meta.title or "Untitled")
    composer = escape(score.meta.composer or "")
    beats = score.meta.time.beats
    beat_type = score.meta.time.beat_type
    measures = max(1, score.meta.measures)

    notes_by_part: dict[str, list[NoteEvent]] = {p.id: [] for p in score.parts}
    for n in score.notes:
        if n.part_id in notes_by_part:
            notes_by_part[n.part_id].append(n)
    for pid in notes_by_part:
        notes_by_part[pid].sort(key=lambda x: x.start_q)

    part_list_xml = []
    for p in score.parts:
        part_list_xml.append(
            f"<score-part id=\"{p.id}\"><part-name>{escape(p.name)}</part-name></score-part>"
        )

    parts_xml = []
    for p in score.parts:
        measures_xml = []
        for m in range(1, measures + 1):
            measure_start_q = (m - 1) * beats
            measure_end_q = m * beats
            m_notes = [n for n in notes_by_part[p.id] if measure_start_q <= n.start_q < measure_end_q]
            m_notes.sort(key=lambda x: x.start_q)

            content = []
            if m == 1:
                staves_tag = f"<staves>{p.staff_count}</staves>" if p.staff_count > 1 else ""
                clefs = []
                if p.staff_count == 2:
                    clefs.append(clef_to_musicxml("treble", 1))
                    clefs.append(clef_to_musicxml("bass", 2))
                else:
                    clefs.append(clef_to_musicxml(p.clef, 1))

                attrs = (
                    "<attributes>"
                    "<divisions>1</divisions>"
                    f"<key><fifths>{score.meta.key.fifths}</fifths></key>"
                    f"<time><beats>{beats}</beats><beat-type>{beat_type}</beat-type></time>"
                    f"{staves_tag}"
                    + "".join(clefs) +
                    "</attributes>"
                )
                direction = (
                    "<direction placement=\"above\">"
                    "<direction-type><metronome><beat-unit>quarter</beat-unit>"
                    f"<per-minute>{score.meta.tempo_bpm}</per-minute>"
                    "</metronome></direction-type></direction>"
                )
                content.append(attrs)
                content.append(direction)

            for n in m_notes:
                step, alter, octave = midi_to_pitch(n.midi)
                alter_xml = f"<alter>{alter}</alter>" if alter != 0 else ""
                note_type = note_type_from_dur(n.dur_q)
                duration = max(1, int(round(n.dur_q)))
                staff_xml = f"<staff>{n.staff}</staff>" if p.staff_count > 1 else ""
                voice_xml = f"<voice>{n.voice}</voice>"

                content.append(
                    "<note>"
                    f"<pitch><step>{step}</step>{alter_xml}<octave>{octave}</octave></pitch>"
                    f"<duration>{duration}</duration>"
                    f"{voice_xml}"
                    f"<type>{note_type}</type>"
                    f"{staff_xml}"
                    "</note>"
                )

            measures_xml.append(f"<measure number=\"{m}\">" + "".join(content) + "</measure>")

        parts_xml.append(f"<part id=\"{p.id}\">" + "".join(measures_xml) + "</part>")

    xml = (
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>"
        "<!DOCTYPE score-partwise PUBLIC "
        "\"-//Recordare//DTD MusicXML 3.1 Partwise//EN\" "
        "\"http://www.musicxml.org/dtds/partwise.dtd\">"
        "<score-partwise version=\"3.1\">"
        f"<work><work-title>{title}</work-title></work>"
        f"<identification><creator type=\"composer\">{composer}</creator></identification>"
        "<part-list>" + "".join(part_list_xml) + "</part-list>"
        + "".join(parts_xml) +
        "</score-partwise>"
    )
    return xml
