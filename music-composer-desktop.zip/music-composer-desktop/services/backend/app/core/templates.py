from app.core.score_schema import Score, ScoreMeta, Part

def make_grand_staff(title: str) -> Score:
    meta = ScoreMeta(title=title, tempo_bpm=100, measures=8)
    piano = Part(id="P1", name="Piano", instrument="piano", clef="treble", staff_count=2)
    return Score(meta=meta, parts=[piano], notes=[])

def make_string_quartet(title: str) -> Score:
    meta = ScoreMeta(title=title, tempo_bpm=100, measures=8)
    parts = [
        Part(id="V1", name="Violin I", instrument="violin", clef="treble", staff_count=1),
        Part(id="V2", name="Violin II", instrument="violin", clef="treble", staff_count=1),
        Part(id="VA", name="Viola", instrument="viola", clef="alto", staff_count=1),
        Part(id="VC", name="Cello", instrument="cello", clef="bass", staff_count=1),
    ]
    return Score(meta=meta, parts=parts, notes=[])
