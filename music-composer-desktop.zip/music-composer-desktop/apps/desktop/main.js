import { app, BrowserWindow } from "electron";
import path from "node:path";
import { spawn } from "node:child_process";
import http from "node:http";

const BACKEND_PORT = 8765;
let backendProc = null;

function waitForHealth(url, timeoutMs = 10000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      const req = http.get(url, (res) => {
        if (res.statusCode === 200) {
          res.resume();
          resolve(true);
        } else {
          res.resume();
          retry();
        }
      });
      req.on("error", retry);
      function retry() {
        if (Date.now() - start > timeoutMs) return reject(new Error("Backend health timeout"));
        setTimeout(tick, 250);
      }
    };
    tick();
  });
}

function startBackend() {
  // Dev convenience: spawn uvicorn from services/backend.
  // In production you will bundle Python (PyInstaller) and spawn the exe instead.
  const backendDir = path.join(app.getAppPath(), "..", "..", "services", "backend");
  if (app.isPackaged) return;

  backendProc = spawn(
    "python",
    ["-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", String(BACKEND_PORT)],
    { cwd: backendDir, stdio: "inherit", windowsHide: true }
  );
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  await win.loadURL("http://localhost:5173");
}

app.whenReady().then(async () => {
  startBackend();
  try {
    await waitForHealth(`http://127.0.0.1:${BACKEND_PORT}/health`);
  } catch (e) {
    console.error(e);
  }
  await createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (backendProc) backendProc.kill();
  if (process.platform !== "darwin") app.quit();
});
