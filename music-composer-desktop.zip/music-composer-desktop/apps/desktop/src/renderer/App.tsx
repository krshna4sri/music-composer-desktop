import React, { useEffect, useMemo, useState } from "react";
import OSMDViewer from "./components/OSMDViewer";
import { health, listTemplates, newProject, exportMusicXML, ragQuery } from "./notation/api";
import type { Score, NoteEvent } from "./notation/scoreTypes";

function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

export default function App() {
  const [backendOk, setBackendOk] = useState(false);
  const [templates, setTemplates] = useState<Array<{ id: string; name: string }>>([]);
  const [score, setScore] = useState<Score | null>(null);
  const [musicxml, setMusicxml] = useState("");
  const [question, setQuestion] = useState("Give me ideas like Bach for bars 1–2");
  const [ragAnswer, setRagAnswer] = useState("");

  useEffect(() => {
    (async () => {
      try {
        await health();
        setBackendOk(true);
        setTemplates(await listTemplates());
      } catch (e) {
        console.error(e);
        setBackendOk(false);
      }
    })();
  }, []);

  async function createFromTemplate(templateId: string) {
    const title = templateId === "grand_staff" ? "Grand Staff" : "String Quartet";
    const s = await newProject(templateId, title);
    setScore(s);
    setMusicxml(await exportMusicXML(s));
  }

  async function addDemoNote() {
    if (!score) return;
    const partId = score.parts[0]?.id;
    if (!partId) return;

    const n: NoteEvent = {
      id: uid("n"),
      part_id: partId,
      voice: 1,
      staff: score.parts[0].staff_count === 2 ? 1 : 1,
      midi: 60,     // C4
      start_q: 0,   // bar1 beat1
      dur_q: 1,     // quarter
      velocity: 90,
    };

    const next: Score = { ...score, notes: [...score.notes, n] };
    setScore(next);
    setMusicxml(await exportMusicXML(next));
  }

  async function askRag() {
    const r = await ragQuery(question, "Bach");
    setRagAnswer(r.answer);
  }

  const leftPanel = useMemo(() => (
    <div style={{ padding: 12, width: 360, borderRight: "1px solid #ddd", background: "#fafafa" }}>
      <div style={{ fontWeight: 700, marginBottom: 8 }}>Music Composer (MVP)</div>
      <div style={{ marginBottom: 12, color: backendOk ? "green" : "red" }}>
        Backend: {backendOk ? "connected" : "not connected"}
      </div>

      <div style={{ marginBottom: 8, fontWeight: 600 }}>Project Templates</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
        {templates.map((t) => (
          <button key={t.id} onClick={() => createFromTemplate(t.id)} style={{ padding: 10, cursor: "pointer" }}>
            {t.name}
          </button>
        ))}
      </div>

      <div style={{ marginBottom: 8, fontWeight: 600 }}>Quick Actions</div>
      <button
        disabled={!score}
        onClick={addDemoNote}
        style={{ padding: 10, cursor: score ? "pointer" : "not-allowed", width: "100%" }}
      >
        Add demo note (C4 quarter @ bar1 beat1)
      </button>

      <hr style={{ margin: "16px 0" }} />

      <div style={{ marginBottom: 8, fontWeight: 600 }}>AI / RAG (stub)</div>
      <textarea value={question} onChange={(e) => setQuestion(e.target.value)} rows={4} style={{ width: "100%", padding: 8 }} />
      <button onClick={askRag} style={{ padding: 10, marginTop: 8, width: "100%", cursor: "pointer" }}>
        Ask
      </button>
      <div style={{ marginTop: 10, whiteSpace: "pre-wrap", fontSize: 13, lineHeight: 1.35 }}>
        {ragAnswer || "Ask for ideas like Bach/Mozart/Beethoven, or ask why something is flagged."}
      </div>
    </div>
  ), [backendOk, templates, score, question, ragAnswer]);

  return (
    <div style={{ display: "flex", height: "100vh", width: "100vw", fontFamily: "ui-sans-serif, system-ui, Segoe UI, Roboto" }}>
      {leftPanel}
      <div style={{ flex: 1, minWidth: 0 }}>
        {musicxml ? (
          <OSMDViewer musicxml={musicxml} />
        ) : (
          <div style={{ padding: 24, color: "#444" }}>
            Choose a template on the left to create a score, then we will render it here.
          </div>
        )}
      </div>
    </div>
  );
}
