import axios from "axios";
import type { Score } from "./scoreTypes";

const BASE = "http://127.0.0.1:8765";

export async function health() {
  const r = await axios.get(`${BASE}/health`);
  return r.data;
}

export async function listTemplates() {
  const r = await axios.get(`${BASE}/templates`);
  return r.data as Array<{ id: string; name: string }>;
}

export async function newProject(template_id: string, title?: string) {
  const r = await axios.post(`${BASE}/templates/new`, { template_id, title });
  return r.data as Score;
}

export async function exportMusicXML(score: Score) {
  const r = await axios.post(`${BASE}/export/musicxml`, score);
  return (r.data as { musicxml: string }).musicxml;
}

export async function ragQuery(question: string, style_hint?: string) {
  const r = await axios.post(`${BASE}/rag/query`, { question, style_hint });
  return r.data as { answer: string; citations: any[]; suggested_actions: any[] };
}
