export type Clef = "treble" | "bass" | "alto" | "tenor";
export type InstrumentId = "piano" | "violin" | "viola" | "cello";

export type TimeSignature = { beats: number; beat_type: number };
export type KeySignature = { fifths: number };

export type ScoreMeta = {
  title: string;
  composer?: string;
  tempo_bpm: number;
  time: TimeSignature;
  key: KeySignature;
  measures: number;
};

export type Part = {
  id: string;
  name: string;
  instrument: InstrumentId;
  clef: Clef;
  staff_count: number;
};

export type NoteEvent = {
  id: string;
  part_id: string;
  voice: number;
  staff: number;
  midi: number;
  start_q: number;
  dur_q: number;
  velocity: number;
};

export type Score = {
  meta: ScoreMeta;
  parts: Part[];
  notes: NoteEvent[];
};
