import React, { useEffect, useRef } from "react";
import { OpenSheetMusicDisplay } from "opensheetmusicdisplay";

type Props = { musicxml: string };

export default function OSMDViewer({ musicxml }: Props) {
  const divRef = useRef<HTMLDivElement | null>(null);
  const osmdRef = useRef<OpenSheetMusicDisplay | null>(null);

  useEffect(() => {
    if (!divRef.current) return;

    if (!osmdRef.current) {
      osmdRef.current = new OpenSheetMusicDisplay(divRef.current, {
        autoResize: true,
        drawTitle: true,
      });
    }

    const osmd = osmdRef.current;
    (async () => {
      await osmd.load(musicxml);
      osmd.render();
    })();
  }, [musicxml]);

  return <div ref={divRef} style={{ width: "100%", height: "100%", overflow: "auto", background: "#fff" }} />;
}
