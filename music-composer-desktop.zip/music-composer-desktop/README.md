# Music Composer Desktop (Electron + Python backend) — MVP Scaffold (Windows + Ollama)

This is a working starter scaffold for a desktop music composing app:
- **Electron + React (renderer)**
- **Python FastAPI backend**
- **MusicXML rendering** via OpenSheetMusicDisplay (OSMD)
- **Project templates**: Grand Staff (Piano) + String Quartet
- **ScoreJSON** canonical model
- Basic "Add note" to prove end-to-end flow (ScoreJSON → MusicXML → OSMD)

## Prereqs (Windows)
- Node.js 18+
- Python 3.10+ (recommended 3.11)
- (Optional for later) Ollama installed and running

## Run (Dev)
### 1) Backend
```bash
cd services/backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8765 --reload
```

### 2) Desktop app
```bash
cd apps/desktop
npm install
npm run dev
```

The Electron app will:
- call backend `/health`
- let you create a project from templates
- render the score in OSMD
- add a demo note and re-render

## Next steps (plug in your 4 pillars)
Adapters are pre-wired as endpoints:
- `/rag/query` (currently stub)
- `/generate` (currently stub)
- `/constraints/validate` + `/constraints/repair` (stubs)

Drop your existing logic in backend adapters under `services/backend/app/engines/*`
and route from `app/core/orchestration.py` (to be added in Phase 2).

---
Generated: 2026-02-27T21:54:43
